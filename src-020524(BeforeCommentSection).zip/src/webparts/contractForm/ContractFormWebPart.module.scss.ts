/* tslint:disable */
require("./ContractFormWebPart.module.css");
const styles = {
  contractForm: 'contractForm_0753c23b',
  'info-text': 'info-text_0753c23b',
  'form-group': 'form-group_0753c23b',
  title: 'title_0753c23b',
  heading: 'heading_0753c23b',
  controls: 'controls_0753c23b',
  active: 'active_0753c23b',
  longduree_button: 'longduree_button_0753c23b',
  clear: 'clear_0753c23b',
  grid: 'grid_0753c23b',
  'col-2-3': 'col-2-3_0753c23b',
  'col-1-3': 'col-1-3_0753c23b',
  'col-1-2': 'col-1-2_0753c23b',
  'col-1-4': 'col-1-4_0753c23b',
  'col-1-4-sm': 'col-1-4-sm_0753c23b',
  'col-1-3-sm': 'col-1-3-sm_0753c23b',
  'col-1-8': 'col-1-8_0753c23b',
  buttoncss: 'buttoncss_0753c23b',
  welcome: 'welcome_0753c23b',
  welcomeImage: 'welcomeImage_0753c23b',
  links: 'links_0753c23b'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./RequestFormWebPart.module.css");
const styles = {
  requestForm: 'requestForm_ff17dad0',
  'info-text': 'info-text_ff17dad0',
  'form-group': 'form-group_ff17dad0',
  title: 'title_ff17dad0',
  heading: 'heading_ff17dad0',
  controls: 'controls_ff17dad0',
  active: 'active_ff17dad0',
  longduree_button: 'longduree_button_ff17dad0',
  clear: 'clear_ff17dad0',
  grid: 'grid_ff17dad0',
  'col-2-3': 'col-2-3_ff17dad0',
  'col-1-3': 'col-1-3_ff17dad0',
  'col-1-2': 'col-1-2_ff17dad0',
  'col-1-4': 'col-1-4_ff17dad0',
  'col-1-4-sm': 'col-1-4-sm_ff17dad0',
  'col-1-3-sm': 'col-1-3-sm_ff17dad0',
  'col-1-8': 'col-1-8_ff17dad0',
  buttoncss: 'buttoncss_ff17dad0',
  welcome: 'welcome_ff17dad0',
  welcomeImage: 'welcomeImage_ff17dad0',
  links: 'links_ff17dad0'
};

export default styles;
/* tslint:enable */
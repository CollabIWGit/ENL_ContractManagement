/* tslint:disable */
require("./bootstrap-grid.css");
const styles = {

};

export default styles;
/* tslint:enable */
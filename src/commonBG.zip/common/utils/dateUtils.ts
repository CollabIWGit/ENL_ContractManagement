// export class dateUtils {
//   public formatDate(date): string {
//     var d = new Date(date),
//       month = '' + (d.getMonth() + 1),
//       day = '' + d.getDate(),
//       year = d.getFullYear();

//     if (month.length < 2)
//       month = '0' + month;
//     if (day.length < 2)
//       day = '0' + day;
//     return [year, month, day].join('-');
//   }

//   public formatDateWithTimestamp(date): string {
//     const d = new Date(date);
//     const date_part = d.toISOString().split('T')[0];
//     const time_part = d.toTimeString().split(' ')[0];
//     return `${date_part} ${time_part}`;
//   }

//   public getNumberOfDays(start, end) {
//     const date1 = new Date(start);
//     const date2 = new Date(end);

//     // One day in milliseconds
//     const oneDay = 1000 * 60 * 60 * 24;

//     // Calculating the time difference between two dates
//     const diffInTime = date2.getTime() - date1.getTime();

//     // Calculating the no. of days between two dates
//     const diffInDays = Math.round(diffInTime / oneDay);

//     return diffInDays;
//   }

// }
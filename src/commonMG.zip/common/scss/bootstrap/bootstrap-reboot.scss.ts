/* tslint:disable */
require("./bootstrap-reboot.css");
const styles = {

};

export default styles;
/* tslint:enable */
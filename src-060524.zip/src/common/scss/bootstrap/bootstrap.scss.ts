/* tslint:disable */
require("./bootstrap.css");
const styles = {

};

export default styles;
/* tslint:enable */
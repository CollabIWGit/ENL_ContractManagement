/* tslint:disable */
require("./RequestFormWebPart.module.css");
const styles = {
  requestForm: 'requestForm_c05c7167',
  'info-text': 'info-text_c05c7167',
  'form-group': 'form-group_c05c7167',
  title: 'title_c05c7167',
  heading: 'heading_c05c7167',
  controls: 'controls_c05c7167',
  active: 'active_c05c7167',
  longduree_button: 'longduree_button_c05c7167',
  clear: 'clear_c05c7167',
  grid: 'grid_c05c7167',
  'col-2-3': 'col-2-3_c05c7167',
  'col-1-3': 'col-1-3_c05c7167',
  'col-1-2': 'col-1-2_c05c7167',
  'col-1-4': 'col-1-4_c05c7167',
  'col-1-4-sm': 'col-1-4-sm_c05c7167',
  'col-1-3-sm': 'col-1-3-sm_c05c7167',
  'col-1-8': 'col-1-8_c05c7167',
  buttoncss: 'buttoncss_c05c7167',
  welcome: 'welcome_c05c7167',
  welcomeImage: 'welcomeImage_c05c7167',
  links: 'links_c05c7167'
};

export default styles;
/* tslint:enable */
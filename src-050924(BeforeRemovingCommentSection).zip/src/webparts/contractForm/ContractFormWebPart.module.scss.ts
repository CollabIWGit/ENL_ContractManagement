/* tslint:disable */
require("./ContractFormWebPart.module.css");
const styles = {
  contractForm: 'contractForm_f616b1a7',
  'info-text': 'info-text_f616b1a7',
  'form-group': 'form-group_f616b1a7',
  title: 'title_f616b1a7',
  heading: 'heading_f616b1a7',
  controls: 'controls_f616b1a7',
  active: 'active_f616b1a7',
  longduree_button: 'longduree_button_f616b1a7',
  clear: 'clear_f616b1a7',
  grid: 'grid_f616b1a7',
  'col-1': 'col-1_f616b1a7',
  'col-2-3': 'col-2-3_f616b1a7',
  'col-1-3': 'col-1-3_f616b1a7',
  'col-1-2': 'col-1-2_f616b1a7',
  'col-1-4': 'col-1-4_f616b1a7',
  'col-1-6': 'col-1-6_f616b1a7',
  'col-03': 'col-03_f616b1a7',
  'col-05': 'col-05_f616b1a7',
  'col-1-4-sm': 'col-1-4-sm_f616b1a7',
  'col-1-3-sm': 'col-1-3-sm_f616b1a7',
  'col-1-8': 'col-1-8_f616b1a7',
  buttoncss: 'buttoncss_f616b1a7',
  welcome: 'welcome_f616b1a7',
  welcomeImage: 'welcomeImage_f616b1a7',
  links: 'links_f616b1a7',
  addPartiesButton: 'addPartiesButton_f616b1a7',
  'custom-table': 'custom-table_f616b1a7',
  termOfContract: 'termOfContract_f616b1a7',
  submitBtnDiv: 'submitBtnDiv_f616b1a7',
  errorSpan: 'errorSpan_f616b1a7'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./WorkingAreaWebPart.module.css");
const styles = {
  workingArea: 'workingArea_79f83494',
  'info-text': 'info-text_79f83494',
  'form-group': 'form-group_79f83494',
  title: 'title_79f83494',
  heading: 'heading_79f83494',
  controls: 'controls_79f83494',
  active: 'active_79f83494',
  longduree_button: 'longduree_button_79f83494',
  clear: 'clear_79f83494',
  grid: 'grid_79f83494',
  'col-2-3': 'col-2-3_79f83494',
  'col-1-3': 'col-1-3_79f83494',
  'col-1-2': 'col-1-2_79f83494',
  'col-1-4': 'col-1-4_79f83494',
  'col-1-4-sm': 'col-1-4-sm_79f83494',
  'col-1-3-sm': 'col-1-3-sm_79f83494',
  'col-1-8': 'col-1-8_79f83494',
  buttoncss: 'buttoncss_79f83494',
  addPartiesButton: 'addPartiesButton_79f83494',
  welcome: 'welcome_79f83494',
  welcomeImage: 'welcomeImage_79f83494',
  links: 'links_79f83494',
  contractContainer: 'contractContainer_79f83494',
  existingFilesDatatable: 'existingFilesDatatable_79f83494',
  contractVersionsTable: 'contractVersionsTable_79f83494',
  datatableBtn: 'datatableBtn_79f83494',
  datatableBtnImg: 'datatableBtnImg_79f83494',
  hideDisplay: 'hideDisplay_79f83494',
  contractDetailsFS: 'contractDetailsFS_79f83494',
  datatableLegends: 'datatableLegends_79f83494'
};

export default styles;
/* tslint:enable */
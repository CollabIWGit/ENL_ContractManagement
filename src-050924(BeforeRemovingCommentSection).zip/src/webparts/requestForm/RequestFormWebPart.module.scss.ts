/* tslint:disable */
require("./RequestFormWebPart.module.css");
const styles = {
  requestForm: 'requestForm_f728069f',
  'info-text': 'info-text_f728069f',
  addPartiesButton: 'addPartiesButton_f728069f',
  'form-group': 'form-group_f728069f',
  title: 'title_f728069f',
  heading: 'heading_f728069f',
  controls: 'controls_f728069f',
  active: 'active_f728069f',
  longduree_button: 'longduree_button_f728069f',
  clear: 'clear_f728069f',
  grid: 'grid_f728069f',
  'col-2-3': 'col-2-3_f728069f',
  'col-1-3': 'col-1-3_f728069f',
  'col-1-2': 'col-1-2_f728069f',
  'col-1-4': 'col-1-4_f728069f',
  'col-1-4-sm': 'col-1-4-sm_f728069f',
  'col-1-3-sm': 'col-1-3-sm_f728069f',
  'col-1-8': 'col-1-8_f728069f',
  buttoncss: 'buttoncss_f728069f',
  dropdownPadding: 'dropdownPadding_f728069f',
  welcome: 'welcome_f728069f',
  welcomeImage: 'welcomeImage_f728069f',
  links: 'links_f728069f',
  legalLegend: 'legalLegend_f728069f',
  requiredFieldsLabel: 'requiredFieldsLabel_f728069f',
  'was-validated': 'was-validated_f728069f',
  'is-invalid': 'is-invalid_f728069f',
  'is-valid': 'is-valid_f728069f',
  errorSpan: 'errorSpan_f728069f',
  contributorEntryContainer: 'contributorEntryContainer_f728069f',
  contributorEntry: 'contributorEntry_f728069f',
  contributorEmail: 'contributorEmail_f728069f',
  removeButton: 'removeButton_f728069f',
  emailPermissionContainer: 'emailPermissionContainer_f728069f',
  emailPermission: 'emailPermission_f728069f',
  removePermission: 'removePermission_f728069f',
  permissionContainer: 'permissionContainer_f728069f'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./SignatoriesWebPart.module.css");
const styles = {
  signatories: 'signatories_0de56328',
  'info-text': 'info-text_0de56328',
  addPartiesButton: 'addPartiesButton_0de56328',
  'form-group': 'form-group_0de56328',
  title: 'title_0de56328',
  heading: 'heading_0de56328',
  controls: 'controls_0de56328',
  active: 'active_0de56328',
  longduree_button: 'longduree_button_0de56328',
  clear: 'clear_0de56328',
  grid: 'grid_0de56328',
  'col-2-3': 'col-2-3_0de56328',
  'col-1-3': 'col-1-3_0de56328',
  'col-1-2': 'col-1-2_0de56328',
  'col-1-4': 'col-1-4_0de56328',
  'col-1-4-sm': 'col-1-4-sm_0de56328',
  'col-1-3-sm': 'col-1-3-sm_0de56328',
  'col-1-8': 'col-1-8_0de56328',
  buttoncss: 'buttoncss_0de56328',
  welcome: 'welcome_0de56328',
  welcomeImage: 'welcomeImage_0de56328',
  links: 'links_0de56328',
  legalLegend: 'legalLegend_0de56328',
  requiredFieldsLabel: 'requiredFieldsLabel_0de56328',
  'was-validated': 'was-validated_0de56328',
  'is-invalid': 'is-invalid_0de56328',
  'is-valid': 'is-valid_0de56328',
  fieldsetSig: 'fieldsetSig_0de56328',
  legendSig: 'legendSig_0de56328',
  submitBtnDiv: 'submitBtnDiv_0de56328'
};

export default styles;
/* tslint:enable */
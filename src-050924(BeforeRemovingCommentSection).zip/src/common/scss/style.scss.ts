/* tslint:disable */
require("./style.css");
const styles = {

};

export default styles;
/* tslint:enable */
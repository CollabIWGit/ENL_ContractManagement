/* tslint:disable */
require("./ContractFormWebPart.module.css");
const styles = {
  contractForm: 'contractForm_0811e56b',
  'info-text': 'info-text_0811e56b',
  'form-group': 'form-group_0811e56b',
  title: 'title_0811e56b',
  heading: 'heading_0811e56b',
  controls: 'controls_0811e56b',
  active: 'active_0811e56b',
  longduree_button: 'longduree_button_0811e56b',
  clear: 'clear_0811e56b',
  grid: 'grid_0811e56b',
  'col-1': 'col-1_0811e56b',
  'col-2-3': 'col-2-3_0811e56b',
  'col-1-3': 'col-1-3_0811e56b',
  'col-1-2': 'col-1-2_0811e56b',
  'col-1-4': 'col-1-4_0811e56b',
  'col-1-4-sm': 'col-1-4-sm_0811e56b',
  'col-1-3-sm': 'col-1-3-sm_0811e56b',
  'col-1-8': 'col-1-8_0811e56b',
  buttoncss: 'buttoncss_0811e56b',
  welcome: 'welcome_0811e56b',
  welcomeImage: 'welcomeImage_0811e56b',
  links: 'links_0811e56b'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./RequestFormWebPart.module.css");
const styles = {
  requestForm: 'requestForm_263e3420',
  'info-text': 'info-text_263e3420',
  addPartiesButton: 'addPartiesButton_263e3420',
  'form-group': 'form-group_263e3420',
  title: 'title_263e3420',
  heading: 'heading_263e3420',
  controls: 'controls_263e3420',
  active: 'active_263e3420',
  longduree_button: 'longduree_button_263e3420',
  clear: 'clear_263e3420',
  grid: 'grid_263e3420',
  'col-2-3': 'col-2-3_263e3420',
  'col-1-3': 'col-1-3_263e3420',
  'col-1-2': 'col-1-2_263e3420',
  'col-1-4': 'col-1-4_263e3420',
  'col-1-4-sm': 'col-1-4-sm_263e3420',
  'col-1-3-sm': 'col-1-3-sm_263e3420',
  'col-1-8': 'col-1-8_263e3420',
  buttoncss: 'buttoncss_263e3420',
  welcome: 'welcome_263e3420',
  welcomeImage: 'welcomeImage_263e3420',
  links: 'links_263e3420',
  legalLegend: 'legalLegend_263e3420'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./WorkingAreaWebPart.module.css");
const styles = {
  workingArea: 'workingArea_124abfab',
  'info-text': 'info-text_124abfab',
  'form-group': 'form-group_124abfab',
  title: 'title_124abfab',
  heading: 'heading_124abfab',
  controls: 'controls_124abfab',
  active: 'active_124abfab',
  longduree_button: 'longduree_button_124abfab',
  clear: 'clear_124abfab',
  grid: 'grid_124abfab',
  'col-2-3': 'col-2-3_124abfab',
  'col-1-3': 'col-1-3_124abfab',
  'col-1-2': 'col-1-2_124abfab',
  'col-1-4': 'col-1-4_124abfab',
  'col-1-4-sm': 'col-1-4-sm_124abfab',
  'col-1-3-sm': 'col-1-3-sm_124abfab',
  'col-1-8': 'col-1-8_124abfab',
  buttoncss: 'buttoncss_124abfab',
  addPartiesButton: 'addPartiesButton_124abfab',
  welcome: 'welcome_124abfab',
  welcomeImage: 'welcomeImage_124abfab',
  links: 'links_124abfab',
  contractContainer: 'contractContainer_124abfab',
  existingFilesDatatable: 'existingFilesDatatable_124abfab',
  contractVersionsTable: 'contractVersionsTable_124abfab',
  datatableBtn: 'datatableBtn_124abfab',
  datatableBtnImg: 'datatableBtnImg_124abfab',
  hideDisplay: 'hideDisplay_124abfab',
  contractDetailsFS: 'contractDetailsFS_124abfab',
  datatableLegends: 'datatableLegends_124abfab'
};

export default styles;
/* tslint:enable */
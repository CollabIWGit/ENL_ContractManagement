/* tslint:disable */
require("./EnlCmsWebPart.module.css");
const styles = {
  enlCms: 'enlCms_b6532532',
  teams: 'teams_b6532532',
  welcome: 'welcome_b6532532',
  welcomeImage: 'welcomeImage_b6532532',
  links: 'links_b6532532'
};

export default styles;
/* tslint:enable */